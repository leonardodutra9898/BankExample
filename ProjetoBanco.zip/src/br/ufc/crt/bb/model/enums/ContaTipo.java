package br.ufc.crt.bb.model.enums;

public enum ContaTipo{
	COMUM, ESPECIAL
}