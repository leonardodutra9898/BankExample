package br.ufc.crt.bb.model.enums;

public enum MovimentacoesTipo{
	CREDITO, DEBITO, TRANSFERENCIA
}